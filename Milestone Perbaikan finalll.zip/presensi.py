class Presensi:
    """Rekap presensi satu karyawan untuk satu bulan."""

    def __init__(self, id_karyawan, bulan, tahun):
        self.id_karyawan = id_karyawan
        self.bulan = bulan
        self.tahun = tahun
        self._catatan = {}  # tanggal -> (status, jam_lembur)

    def catat(self, tanggal, status, jam_lembur=0.0):
        if tanggal in self._catatan:
            raise ValueError(f"Presensi tanggal {tanggal} sudah tercatat.")
        status_bersih = status.replace(".", "").replace(" ", "").lower()
        self._catatan[tanggal] = (status_bersih, jam_lembur)

    def _hitung(self, status):
        target = status.replace(".", "").replace(" ", "").lower()
        return sum(
            1 for s, _ in self._catatan.values()
            if s.replace(".", "").replace(" ", "").lower() == target
        )

    @property
    def hari_hadir(self):
        return self._hitung("hadir")

    @property
    def hari_izin(self):
        return self._hitung("izin")

    @property
    def hari_alpha(self):
        return self._hitung("alpha")

    @property
    def jam_lembur(self):
        return sum(lembur for _, lembur in self._catatan.values())

    @property
    def total_hari(self):
        return len(self._catatan)

    def __str__(self):
        return (f"Presensi {self.id_karyawan} ({self.bulan:02d}/{self.tahun}): "
                f"Hadir={self.hari_hadir}, Izin={self.hari_izin}, "
                f"Alpha={self.hari_alpha}, Lembur={self.jam_lembur} jam")
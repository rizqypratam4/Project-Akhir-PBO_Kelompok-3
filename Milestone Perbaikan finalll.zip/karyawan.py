from abc import ABC, abstractmethod

HARI_KERJA = 24  # jumlah hari kerja standar per bulan


class Karyawan(ABC):
    def __init__(self, id_karyawan, nama, jabatan, tanggal_masuk):
        if not id_karyawan or not nama:
            raise ValueError("ID dan nama tidak boleh kosong.")
        self._id_karyawan = id_karyawan
        self._nama = nama
        self._jabatan = jabatan
        self._tanggal_masuk = tanggal_masuk
        self._aktif = True

    @property
    def id_karyawan(self):
        return self._id_karyawan

    @property
    def nama(self):
        return self._nama

    @property
    def jabatan(self):
        return self._jabatan

    @property
    def tanggal_masuk(self):
        return self._tanggal_masuk

    @property
    def aktif(self):
        return self._aktif

    def nonaktifkan(self):
        self._aktif = False

    @abstractmethod
    def hitung_gaji_kotor(self, presensi):
        pass

    @abstractmethod
    def get_jenis(self):
        pass


class KaryawanTetap(Karyawan):
    TARIF_LEMBUR = 20000

    def __init__(self, id_karyawan, nama, jabatan, tanggal_masuk, gaji_pokok, tunjangan):
        super().__init__(id_karyawan, nama, jabatan, tanggal_masuk)
        if gaji_pokok < 0 or tunjangan < 0:
            raise ValueError("Gaji pokok dan tunjangan tidak boleh negatif.")
        self._gaji_pokok = gaji_pokok
        self._tunjangan = tunjangan

    def get_jenis(self):
        return "Tetap"

    def hitung_gaji_kotor(self, presensi):
        lembur = presensi.jam_lembur * self.TARIF_LEMBUR
        potongan_alpha = self._gaji_pokok / HARI_KERJA * presensi.hari_alpha
        total = self._gaji_pokok + self._tunjangan + lembur - potongan_alpha
        return max(0, round(total))


class KaryawanHarian(Karyawan):
    TARIF_LEMBUR = 15000

    def __init__(self, id_karyawan, nama, jabatan, tanggal_masuk, upah_harian):
        super().__init__(id_karyawan, nama, jabatan, tanggal_masuk)
        if upah_harian < 0:
            raise ValueError("Upah harian tidak boleh negatif.")
        self._upah_harian = upah_harian

    def get_jenis(self):
        return "Harian"

    def hitung_gaji_kotor(self, presensi):
        upah = presensi.hari_hadir * self._upah_harian
        lembur = presensi.jam_lembur * self.TARIF_LEMBUR
        return round(upah + lembur)
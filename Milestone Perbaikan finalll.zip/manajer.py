from datetime import datetime

from karyawan import Karyawan, HARI_KERJA
from presensi import Presensi
from slip_gaji import SlipGaji, format_rupiah

STATUS_VALID = ("hadir", "izin", "alpha")
BATAS_LEMBUR = 72  # jam per bulan


def bersihkan_status(teks):
    return teks.replace(".", "").replace(" ", "").lower()


def bersihkan_id(teks):
    return teks.replace(".", "").replace(" ", "").upper()


def cek_periode(bulan, tahun):
    if not 1 <= bulan <= 12:
        raise ValueError("Bulan harus 1 sampai 12.")
    if tahun < 2000:
        raise ValueError("Tahun tidak valid.")


class ManajerPenggajian:
    def __init__(self):
        self._karyawan = {}  # id -> Karyawan
        self._presensi = {}  # (id, bulan, tahun) -> Presensi
        self._slip = {}      # (id, bulan, tahun) -> SlipGaji

    # ---------- karyawan ----------
    def _get_karyawan(self, id_karyawan):
        id_bersih = bersihkan_id(id_karyawan)
        karyawan = self._karyawan.get(id_bersih)
        if karyawan is None:
            raise ValueError(f"Karyawan {id_bersih} tidak ditemukan.")
        return karyawan

    def tambah_karyawan(self, karyawan):
        if not isinstance(karyawan, Karyawan):
            raise TypeError("Objek harus turunan dari Karyawan.")
        id_bersih = bersihkan_id(karyawan.id_karyawan)
        karyawan._id_karyawan = id_bersih
        if id_bersih in self._karyawan:
            raise ValueError(f"ID {id_bersih} sudah dipakai.")
        self._karyawan[id_bersih] = karyawan

    def nonaktifkan_karyawan(self, id_karyawan):
        self._get_karyawan(id_karyawan).nonaktifkan()

    def tampilkan_karyawan(self):
        if not self._karyawan:
            print("Belum ada data karyawan.")
            return
        print(f"{'ID':<9}{'Nama':<20}{'Jabatan':<20}{'Jenis':<8}Status")
        print("-" * 64)
        for k in self._karyawan.values():
            status = "Aktif" if k.aktif else "Nonaktif"
            print(f"{k.id_karyawan:<9}{k.nama:<20}{k.jabatan:<20}{k.get_jenis():<8}{status}")

    # ---------- presensi ----------
    def catat_presensi(self, id_karyawan, tanggal, status, jam_lembur=0.0):
        karyawan = self._get_karyawan(id_karyawan)
        id_bersih = karyawan.id_karyawan
        if not karyawan.aktif:
            raise ValueError(f"Karyawan {id_bersih} sudah nonaktif.")

        tanggal_bersih = tanggal.replace(".", "").strip()
        try:
            tgl = datetime.strptime(tanggal_bersih, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Format tanggal harus YYYY-MM-DD.")

        status = bersihkan_status(status)
        if status not in STATUS_VALID:
            raise ValueError("Status harus 'hadir', 'izin', atau 'alpha'.")
        if jam_lembur < 0:
            raise ValueError("Jam lembur tidak boleh negatif.")
        if status != "hadir" and jam_lembur > 0:
            raise ValueError("Lembur hanya boleh untuk status hadir.")

        kunci = (id_bersih, tgl.month, tgl.year)
        if kunci in self._slip:
            raise ValueError("Slip periode ini sudah dibuat, presensi tidak bisa diubah.")

        presensi = self._presensi.get(kunci)
        if presensi is None:
            presensi = Presensi(id_bersih, tgl.month, tgl.year)

        if presensi.total_hari >= HARI_KERJA:
            raise ValueError(f"Total hari presensi sudah mencapai {HARI_KERJA} hari.")
        if presensi.jam_lembur + jam_lembur > BATAS_LEMBUR:
            raise ValueError(f"Total lembur melebihi {BATAS_LEMBUR} jam per bulan.")

        presensi.catat(tanggal_bersih, status, jam_lembur)
        self._presensi[kunci] = presensi

    def lihat_presensi(self, id_karyawan, bulan, tahun):
        cek_periode(bulan, tahun)
        return self._presensi.get((bersihkan_id(id_karyawan), bulan, tahun))

    # ---------- penggajian ----------
    def proses_gaji(self, bulan, tahun):
        cek_periode(bulan, tahun)
        hasil = {"dibuat": [], "sudah_ada": [], "tanpa_presensi": []}

        for k in self._karyawan.values():
            if not k.aktif:
                continue
            kunci = (k.id_karyawan, bulan, tahun)
            presensi = self._presensi.get(kunci)

            if kunci in self._slip:
                hasil["sudah_ada"].append(k.id_karyawan)
            elif presensi is None:
                hasil["tanpa_presensi"].append(k.id_karyawan)
            else:
                kode = f"SLP-{tahun}{bulan:02d}-{k.id_karyawan}"
                slip = SlipGaji(kode, k, presensi, bulan, tahun)
                self._slip[kunci] = slip
                hasil["dibuat"].append(slip)
        return hasil

    def cetak_hasil_proses(self, hasil):
        print(f"Slip dibuat            : {len(hasil['dibuat'])}")
        print(f"Dilewati (sudah ada)   : {len(hasil['sudah_ada'])}")
        print(f"Belum ada presensi     : {len(hasil['tanpa_presensi'])}")
        for id_k in hasil["tanpa_presensi"]:
            print(f"  - {id_k} ({self._karyawan[id_k].nama})")

    def cetak_slip(self, id_karyawan, bulan, tahun):
        id_bersih = bersihkan_id(id_karyawan)
        slip = self._slip.get((id_bersih, bulan, tahun))
        if slip is None:
            raise ValueError(f"Slip {id_bersih} periode {bulan:02d}/{tahun} belum dibuat.")
        slip.cetak_slip()

    def cetak_laporan_periode(self, bulan, tahun):
        cek_periode(bulan, tahun)
        daftar = sorted(
            (s for (_, b, t), s in self._slip.items() if (b, t) == (bulan, tahun)),
            key=lambda s: s.karyawan.id_karyawan,
        )

        print("=" * 78)
        print(f"LAPORAN PENGGAJIAN {bulan:02d}/{tahun}")
        print("=" * 78)
        if not daftar:
            print("Belum ada slip gaji pada periode ini.")
            return

        print(f"{'ID':<9}{'Nama':<20}{'Jenis':<8}{'Gaji Kotor':>14}{'BPJS':>12}{'Gaji Bersih':>14}")
        print("-" * 78)
        for s in daftar:
            k = s.karyawan
            print(f"{k.id_karyawan:<9}{k.nama:<20}{k.get_jenis():<8}"
                  f"{format_rupiah(s.gaji_kotor):>14}"
                  f"{format_rupiah(s.potongan_bpjs):>12}"
                  f"{format_rupiah(s.gaji_bersih):>14}")
        print("-" * 78)
        print(f"Jumlah slip         : {len(daftar)}")
        print(f"Total gaji kotor    : {format_rupiah(sum(s.gaji_kotor for s in daftar))}")
        print(f"Total potongan BPJS : {format_rupiah(sum(s.potongan_bpjs for s in daftar))}")
        print(f"Total gaji bersih   : {format_rupiah(sum(s.gaji_bersih for s in daftar))}")
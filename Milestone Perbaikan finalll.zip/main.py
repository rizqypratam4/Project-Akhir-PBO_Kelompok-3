import sys

from karyawan import KaryawanTetap, KaryawanHarian
from manajer import ManajerPenggajian


def isi_data_contoh(manajer):
    manajer.tambah_karyawan(KaryawanTetap("EMP-001", "Ahmad Rian", "Software Engineer", "2023-01-15", 7000000, 1000000))
    manajer.tambah_karyawan(KaryawanTetap("EMP-002", "Siti Aisyah", "Product Manager", "2022-05-10", 9000000, 1500000))
    manajer.tambah_karyawan(KaryawanHarian("EMP-003", "Budi Santoso", "UI/UX Designer", "2024-02-01", 200000))

    # EMP-001: 20 hari hadir (lembur 2 jam di dua hari pertama), 2 hari alpha
    for i in range(1, 21):
        lembur = 2.0 if i <= 2 else 0.0
        manajer.catat_presensi("EMP-001", f"2026-05-{i:02d}", "hadir", lembur)
    manajer.catat_presensi("EMP-001", "2026-05-21", "alpha")
    manajer.catat_presensi("EMP-001", "2026-05-22", "alpha")

    # EMP-002: 22 hari hadir
    for i in range(1, 24):
        manajer.catat_presensi("EMP-002", f"2026-05-{i:02d}", "hadir")


def input_periode():
    bulan = int(input("Bulan (1-12): "))
    tahun = int(input("Tahun       : "))
    return bulan, tahun


def menu_karyawan(manajer):
    while True:
        print("\n--- KELOLA KARYAWAN ---")
        print("1. Lihat semua karyawan")
        print("2. Tambah karyawan tetap")
        print("3. Tambah karyawan harian")
        print("4. Nonaktifkan karyawan")
        print("0. Kembali")
        pilihan = input("Pilih: ").strip()

        try:
            if pilihan == "1":
                manajer.tampilkan_karyawan()
            elif pilihan in ("2", "3"):
                id_k = input("ID Karyawan          : ").replace(".", "").replace(" ", "").upper()
                nama = " ".join(input("Nama                 : ").replace(".", "").split()).title()
                jabatan = " ".join(input("Jabatan              : ").split()).title()
                tgl = input("Tgl masuk (YYYY-MM-DD): ").replace(".", "").strip()
                if pilihan == "2":
                    gaji = float(input("Gaji pokok           : "))
                    tunj = float(input("Tunjangan jabatan    : "))
                    manajer.tambah_karyawan(KaryawanTetap(id_k, nama, jabatan, tgl, gaji, tunj))
                else:
                    upah = float(input("Upah harian          : "))
                    manajer.tambah_karyawan(KaryawanHarian(id_k, nama, jabatan, tgl, upah))
                print(">> Karyawan berhasil ditambahkan.")
            elif pilihan == "4":
                manajer.nonaktifkan_karyawan(input("ID karyawan: ").strip())
                print(">> Karyawan dinonaktifkan.")
            elif pilihan == "0":
                return
            else:
                print(">> Pilihan tidak valid.")
        except ValueError as e:
            print(f">> Gagal: {e}")


def menu_presensi(manajer):
    while True:
        print("\n--- PRESENSI ---")
        print("1. Catat presensi harian")
        print("2. Lihat rekap presensi bulanan")
        print("0. Kembali")
        pilihan = input("Pilih: ").strip()

        try:
            if pilihan == "1":
                id_k = input("ID karyawan             : ").strip()
                tgl = input("Tanggal (YYYY-MM-DD)    : ").strip()
                status = input("Status (hadir/izin/alpha): ").strip()
                lembur = 0.0
                status_cek = status.replace(".", "").replace(" ", "").lower()
                if status_cek == "hadir":
                    lembur = float(input("Jam lembur (0 jika tidak ada): ") or 0)
                manajer.catat_presensi(id_k, tgl, status, lembur)
                print(">> Presensi dicatat.")
            elif pilihan == "2":
                id_k = input("ID karyawan: ").strip()
                bulan, tahun = input_periode()
                presensi = manajer.lihat_presensi(id_k, bulan, tahun)
                print(f">> {presensi}" if presensi else ">> Data presensi tidak ditemukan.")
            elif pilihan == "0":
                return
            else:
                print(">> Pilihan tidak valid.")
        except ValueError as e:
            print(f">> Gagal: {e}")


def menu_penggajian(manajer):
    while True:
        print("\n--- PENGGAJIAN ---")
        print("1. Proses gaji bulanan")
        print("2. Cetak slip gaji")
        print("3. Cetak laporan periode")
        print("0. Kembali")
        pilihan = input("Pilih: ").strip()

        try:
            if pilihan == "1":
                bulan, tahun = input_periode()
                print()
                manajer.cetak_hasil_proses(manajer.proses_gaji(bulan, tahun))
            elif pilihan == "2":
                id_k = input("ID karyawan: ").strip()
                bulan, tahun = input_periode()
                print()
                manajer.cetak_slip(id_k, bulan, tahun)
            elif pilihan == "3":
                bulan, tahun = input_periode()
                print()
                manajer.cetak_laporan_periode(bulan, tahun)
            elif pilihan == "0":
                return
            else:
                print(">> Pilihan tidak valid.")
        except ValueError as e:
            print(f">> Gagal: {e}")


def main():
    manajer = ManajerPenggajian()
    isi_data_contoh(manajer)

    while True:
        print("\n=== SISTEM PENGGAJIAN KARYAWAN ===")
        print("1. Kelola data karyawan")
        print("2. Kelola presensi")
        print("3. Penggajian & slip")
        print("0. Keluar")
        pilihan = input("Pilih: ").strip()

        if pilihan == "1":
            menu_karyawan(manajer)
        elif pilihan == "2":
            menu_presensi(manajer)
        elif pilihan == "3":
            menu_penggajian(manajer)
        elif pilihan == "0":
            print("Program selesai.")
            sys.exit(0)
        else:
            print("Pilihan tidak valid.")


if __name__ == "__main__":
    main()